# EnrollmentSystem

Note: Zip niyong idl. Nasa loob ng admin and student ang template. Upload niyo nalang sa folder yung file kung admin or student kayo. Also, don't remove the container, para responsive din siya pag nagcollapse yung sidebar.
